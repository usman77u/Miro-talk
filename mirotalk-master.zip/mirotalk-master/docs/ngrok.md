# MiroTalk P2P - Ngrok

### What is the purpose and functionality of Ngrok?

[https://docs.mirotalk.com/ngrok/ngrok/](https://docs.mirotalk.com/ngrok/ngrok/)

### How to exposing MiroTalk P2P with Ngrok?

[https://docs.mirotalk.com/mirotalk-p2p/ngrok/](https://docs.mirotalk.com/mirotalk-p2p/ngrok/)

---
