'use strict';

// https://github.com/mikecao/umami

const script = document.createElement('script');
script.setAttribute('async', '');
script.setAttribute('src', 'https://stats.mirotalk.com/script.js');
script.setAttribute('data-website-id', 'c7615aa7-ceec-464a-baba-54cb605d7261');
document.head.appendChild(script);
